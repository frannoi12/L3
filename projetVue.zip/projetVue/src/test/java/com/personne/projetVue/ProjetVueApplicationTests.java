package com.personne.projetVue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetVueApplicationTests {

	@Test
	void contextLoads() {
	}

}
