package com.personne.projetVue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetVueApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetVueApplication.class, args);
	}

}
