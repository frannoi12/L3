
// Status succes
export const HTTP_200_OK = 200;
export const HTTP_201_OK = 201;
export const HTTP_204_NO_CONTENT = 204;




// Status Erreur client

export const HTTP_400_BAD_REQUEST = 400;
export const HTTP_404_BAD_REQUEST = 404;

// Status erreur serveur

export const HTTP_500_INTERNAL_SERVER_ERROR = 500;


