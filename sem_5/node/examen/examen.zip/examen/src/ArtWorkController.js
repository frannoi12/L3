
export default class ArtWorkController {

    async create(req, res) {}
 
    async getAll(req, res) {}

    async update(req, res) {}

    async delete(req, res) {}

    async filter(req, res) {}
}
