export default class ArtWorkService {
    getAll() {}
    
    create(_data) {}

    get(_id) {}

    update(_id, _data) {}

    delete(_data) {}
}

