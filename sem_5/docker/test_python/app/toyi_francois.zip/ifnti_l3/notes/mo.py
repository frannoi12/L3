from django.db import models

from models import Personne,Eleve,Enseignant,Matiere,Note
# from notes.models import enseignements
from notes.models import niveau

 
# Create your models here.
