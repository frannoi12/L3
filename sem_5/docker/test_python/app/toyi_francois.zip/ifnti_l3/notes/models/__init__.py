# from .personne import Personne
from .eleve import Eleve
from .enseignant import Enseignant
from .matiere import Matiere
from .note import Note
from .niveau import Niveau  # Si ce n'est pas déjà fait
# from .enseignements import Enseignement
