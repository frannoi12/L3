from .eleve import Eleve
from .professeur import Professeur
from .absence import Absence